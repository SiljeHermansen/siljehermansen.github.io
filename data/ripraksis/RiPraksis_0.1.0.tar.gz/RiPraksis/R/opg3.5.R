opg3.5 <- function(){
  data(kap3)

  #Rangere data
  kap3 <- kap3[order(kap3$omfordeling),]

  #Tomt koordinatsystem
  plot(kap3$hojre, kap3$omfordeling,
       type = "n",
       main = "Forholdet mellem partiers hojreorientering\n og deres holdning til omfordeling",
       ylab = "Omfordeling av rigdom",
       xlab = "Hojreorientering",
       xlim = c(0,10),
       ylim = c(0,10))

  #Te farver fra blå til rød
  col <- colorRampPalette(c("blue", "red"))(n = 10)

  #Tekst
  text(kap3$hojre,
       kap3$omfordeling,
       labels = kap3$parti,
       cex = kap3$vigtighet/5,
       col = col)

  #Tegnforklaring alt. 1
  # legend("topright",
  #        fill = c("blue", "red"),
  #        legend = c("Mindre omfordeling",
  #                   "Mere omfordeling"),
  #        cex = 0.7,
  #        bty = "n")

  #Tegnforklaring alt. 2
  legend("topright",
         legend = c("Lite vigtig tema",
                    "Svært vigtig tema"),
         cex = 0.7,
         pt.cex = c(0.3, 0.7),
         pch = c("A", "A"),
         col = c("blue"),
         bty = "n")
}

