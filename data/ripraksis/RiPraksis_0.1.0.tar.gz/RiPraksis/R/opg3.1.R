opg3.1 <- function(){
  data(kap3)

  #Spredningsdiagram
  plot(kap3$hojre, kap3$omfordeling)

}

