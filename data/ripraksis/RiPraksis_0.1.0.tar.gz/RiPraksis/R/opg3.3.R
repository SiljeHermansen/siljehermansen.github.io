opg3.3 <- function(){
  data(kap3)

  #Rangere data
  kap3 <- kap3[order(kap3$omfordeling),]

  #Tomt koordinatsystem
  plot(kap3$hojre, kap3$omfordeling,
       type = "n",
       main = "Forholdet mellem partiers hojreorientering\n og deres holdning til omfordeling",
       ylab = "Omfordeling av rigdom",
       xlab = "Hojreorientering",
       xlim = c(0,10),
       ylim = c(0,10))

  #Te farver fra blå til rød
  col <- colorRampPalette(c("blue", "red"))(n = 10)

  #Tekst
  text(kap3$hojre,
       kap3$omfordeling,
       labels = kap3$parti,
       col = col)

}

