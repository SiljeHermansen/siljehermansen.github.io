##############################
###Hent inn og opprett data###
##############################

##Set directory##
setwd(paste(mydir, "/Replication files/Model - H1_lag", sep = ""))

#Read in data file##
data1<-read.table("data_H1_dataframe.txt")


Attend.m<-0
Attend.sd<-sd(data1$Attend, na.rm=T)

AttCom.m<-mean(data1$AttCom, na.rm=T)
AttCom.sd<-sd(data1$AttCom, na.rm=T)

Age.m<-mean(data1$Age, na.rm=T)
Age.sd<-sd(data1$Age, na.rm=T)

Time.m<-mean(data1$Time, na.rm=T)
Time.sd<-sd(data1$Time, na.rm=T)

Inc.m<-mean(data1$Inc, na.rm=T)
Uncert.m<-mean(data1$Uncert, na.rm=T)

Career.m<-mean(data1$Career, na.rm=T)

NoCom.m<-mean(data1$NoCom, na.rm=T)

Seats.m<-mean(data1$Seats, na.rm=T)
Seats.sd<-sd(data1$Seats, na.rm=T)

NatPol.m<-mean(data1$NatPol, na.rm=T)
EPLeader.m<-mean(data1$EPLeader, na.rm=T)

Lag.m<-mean(data1$SS_lag, na.rm=T)

data1$EP[data1$EP==5]=1
data1$EP[data1$EP==6]=2
data1$EP[data1$EP==7]=3


levels(data1$List)
levels(data1$List)<-c("1", "2", "3","2")
levels(data1$List)
data1$List<-as.character(data1$List)
data1$List<-as.numeric(data1$List)

id<-unique(data1$EPGroup)
id2<-match(data1$EPGroup, id)
data1$EPGroup=id2

id<-sort(unique(data1$National))
id2<-match(data1$National, id)
data1$National=id2

data1$FutureNA=data1$Future
data1$FutureNA[is.na(data1$Future)]=1
data1$FutureNA[!is.na(data1$Future)]=0

AttComNA=data1$AttCom
AttComNA[is.na(data1$AttCom)]=1
AttComNA[!is.na(data1$AttCom)]=0

CareerNA=data1$Career
CareerNA[is.na(data1$Career)]=1
CareerNA[!is.na(data1$Career)]=0



N.fixef=8
N.beta=5
N.betaNA=3
N.b.att=3
N.list=length(unique(data1$List))
N.group=length(unique(data1$EPGroup))
N.nat=length(unique(data1$National))
N.ep=length(unique(data1$EP))

##Priors:
a0<-rep(0,N.fixef)
A<-diag(0.1,N.fixef)

b0<-rep(0,N.beta)
B<-diag(0.1,N.beta)

c0<-rep(0,N.betaNA)
C<-diag(0.1,N.betaNA)

d0<-rep(0,N.b.att)
D<-diag(0.1,N.b.att)

source("RtoBugs.txt")
writeDatafileR(list(data1,
                    N=dim(data1)[1],
                    N.list=N.list,
                    N.fixef=N.fixef,
                    N.beta=N.beta,
                    N.group=N.group,
                    N.nat=N.nat,
                    N.ep=N.ep,
                    N.betaNA=N.betaNA,
                    N.b.att=N.b.att,
                    d0=d0,
                    D=D,
                    c0=c0,
                    C=C,
                    b0=b0,
                    B=B,
                    a0=a0,
                    A=A,
                    Attend.m=Attend.m,
                    Attendsd=Attend.sd,
                    AttCom.m=AttCom.m,
                    AttComsd=AttCom.sd,
                    NatPol.m=NatPol.m,
                    EPLead.m=EPLeader.m,
                    Inc.m=Inc.m,
                    Uncert.m=Uncert.m,
                    Career.m=Career.m,
                    NoCom.m=NoCom.m,
                    Time.m=Time.m,
                    Time.sd=Time.sd,
                    Seats.m=Seats.m,
                    Seats.sd=Seats.sd,
                    Age.m=Age.m,
                    Age.sd=Age.sd,
                    Lag.m=Lag.m),
               towhere="data.txt")




###################
##Initial values:##
###################

for(i in 1:2){
  beta<-rnorm(N.beta)
  betaNA<-rnorm(N.betaNA)
  beta.att<-rnorm(N.b.att, mean=0, sd=0.1)
  a<-rnorm(1)
  a.mu<-rnorm(1)
  a.tau<-runif(1)
  
  a.list=rnorm(N.fixef, mean=0, sd=0.01)
  mu.list=rnorm(N.fixef)
  tau.list=diag(10,(N.fixef))

  a.ep=rnorm(N.ep)
  mu.ep=rnorm(1)
  tau.ep=runif(1)

  a.group=rnorm(N.group)
  mu.group=rnorm(1)
  tau.gr=runif(1)

  a.nat=rnorm(N.nat, mean=0, sd=0.1)
  mu.nat=rnorm(1)
  tau.nat=runif(1)
  
  tau.att=runif(1)

  Future=data1$Future
  Future[is.na(data1$Future)]=1
  Future[!is.na(data1$Future)]=NA

  Attend=data1$Attend
  Attend[is.na(data1$Attend)]=1
  Attend[!is.na(data1$Attend)]=NA

  NatPol=data1$NatPol
  NatPol[is.na(data1$NatPol)]=1
  NatPol[!is.na(data1$NatPol)]=NA

  EPLeader=data1$EPLeader
  EPLeader[is.na(data1$EPLeader)]=1
  EPLeader[!is.na(data1$EPLeader)]=NA

  Inc=data1$Inc
  Inc[is.na(data1$Inc)]=1
  Inc[!is.na(data1$Inc)]=NA
  
  Career<-data1$Career
  Career[is.na(data1$Career)]=1
  Career[!is.na(data1$Career)]=NA

  Age=data1$Age
  Age[is.na(data1$Age)]=rnorm(1)
  Age[!is.na(data1$Age)]=NA

  Time=data1$Time
  Time[is.na(data1$Time)]=rnorm(1)
  Time[!is.na(data1$Time)]=NA

  Seats=data1$Seats
  Seats[is.na(data1$Seats)]=rnorm(1)
  Seats[!is.na(data1$Seats)]=NA
  
  AttCom=data1$AttCom
  AttCom[is.na(data1$AttCom)]=rnorm(1)
  AttCom[!is.na(data1$AttCom)]=NA

  FutureNA=data1$FutureNA
  FutureNA[is.na(data1$FutureNA)]=rnorm(1)
  FutureNA[!is.na(data1$FutureNA)]=NA
  
  writeDatafileR(list(beta=beta,
                      betaNA=betaNA,
                      beta.att=beta.att,
                      a=a,
                      a.group=a.group,
                      mu.group=mu.group,
                      tau.gr=tau.gr,
                      a.nat=a.nat,
                      mu.nat=mu.nat,
                      tau.nat=tau.nat,
                      a.ep=a.ep,
                    mu.ep=mu.ep,
                    tau.ep=tau.ep,
                    a.list=a.list,
                    mu.list=mu.list,
                    tau.list=tau.list,
                    a.mu=a.mu,
                    a.tau=a.tau,
                    tau.att=tau.att,
                    Future=Future,
                    FutureNA=FutureNA,
                    Attend=Attend,
                    Seats=Seats,
                    NatPol=NatPol,
                    EPLeader=EPLeader,
                    Career=Career,
                    AttCom=AttCom,
                    Inc=Inc,
                    Age=Age,
                    Time=Time),
                 towhere=paste("inits", i, ".txt", sep=""))
}

