setwd("M:/Monografi/Expertise in the EP/JCMS")

MEP<-read.table("TimeSeries/MEP.txt", header=TRUE)
MEP<-MEP[MEP$Year>1,]#Exclude the first year of every EP period (no lag imputed)
MEP<-MEP[MEP$PositionCommittee!="Substitute",]
MEP<-MEP[!is.na(MEP$PolicyParticipationRollCall),]
MEP<-MEP[!is.na(MEP$Loyalty),]

MEP<-MEP[!is.na(MEP$ID),]



id1<-unique(MEP$ID)#make a list of unique ID-numbers
id2<-match(MEP$ID, id1)#match this list with the IDs in the data so as to make a vector with recodedV ID-numbers from 1 to infinity

id.ep1<-unique(MEP$EP)#idem for the parliamentary session in question: session 6 is recoded into 1, and 7 to 2.
id.ep2<-match(MEP$EP, id.ep1)

id.committee1<-unique(MEP$Committee)#idem for committee
id.committee2<-match(MEP$Committee, id.committee1)

id.pos1<-unique(MEP$PositionCommittee.lag)#idem for committee
id.pos2<-match(MEP$PositionCommittee.lag, id.pos1)

id.year1<-unique(MEP$Year)#idem for committee
id.year2<-match(MEP$Year, id.year1)

ID<-MEP[,c("ID")]

ID<-unique(ID)

length(ID)==length(unique(MEP$ID)) #check that there is no variation in observations within each individual (ID)


#Multivariate normal prior for b-parameters.

K=11
mu.prior=rep(0,K)
Sigma.prior=diag(0.1,K)

#Make data set for BUGs.


data1<-MEP[,c("NumberReports_Codecision",
              "NationalPolitics",
              "PolicyNationalPolitics",
              "Loyalty",
              "Incumbent",
              "CommitteeIncumbent",
              "PolicyParticipationRollCall",
              "INI.cum",
              "NumberReports_OwnInitiative",
              "NumberReports_Codecision.lag",
              "Chair.lag")]

data1<-cbind(id2, id.year2, id.committee2, id.ep2, data1)

colnames(data1)<-c("ID",
                   "Year",
                   "Com",
                   "EP",
                   "COD",
                   "NatPol",
                   "PNatPol",
                   "Loyalty",
                   "Inc",
                   "ComInc",
                   "Attend",
                   "INI.cum",
                   "INI",
                   "COD.lag",
                   "Chair")

data1$Attend<-data1$Attend/100

m.natpol=mean(data1$NatPol, na.rm=T)
m.pnatpol=mean(data1$PNatPol, na.rm=T)

source("RtoBugs.txt")
writeDatafileR(list(data1,
                    m.natpol=m.natpol,
                    m.pnpol=m.pnatpol,
                    N.year=length(unique(MEP$Year)),
                    N.com=length(unique(MEP$Committee)),
                    N.ep=length(unique(MEP$EP)),
                    N.id=length(unique(MEP$ID)),
                    N=length(MEP$ID), 
                    K=K,
                    mu.prior=mu.prior,
                    Si.prior=Sigma.prior),
               towhere="model_alt2/data_alt2.txt")
