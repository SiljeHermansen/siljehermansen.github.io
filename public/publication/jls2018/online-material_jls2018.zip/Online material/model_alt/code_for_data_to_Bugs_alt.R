setwd("M:/Monografi/Expertise in the EP/JCMS")

MEP<-read.table("TimeSeries/MEP.txt", header=TRUE)

id1<-unique(MEP$ID)#make a list of unique ID-numbers
id2<-match(MEP$ID, id1)#match this list with the IDs in the data so as to make a vector with recodedV ID-numbers from 1 to infinity

id.ep1<-unique(MEP$EP)#idem for the parliamentary session in question: session 6 is recoded into 1, and 7 to 2.
id.ep2<-match(MEP$EP, id.ep1)

id.committee1<-unique(MEP$Committee)#idem for committee
id.committee2<-match(MEP$Committee, id.committee1)


id.year1<-unique(MEP$Year)#idem for committee
id.year2<-match(MEP$Year, id.year1)

ID<-MEP[,c("ID")]

ID<-unique(ID)

dim(ID)[1]==length(unique(MEP$ID)) #check that there is no variation in observations within each individual (ID)


#Make data set for BUGs.


data1<-MEP[,c("NumberReports_Codecision",
              "NationalPolitics",
              "PolicyNationalPolitics",
              "Loyalty",
              "Incumbent",
              "CommitteeIncumbent",
              "AttendanceCommittee.prop.lag",
              "INI.cum",
              "NumberReports_OwnInitiative",
              "NumberReports_Codecision.lag",
              "Chair.lag")]

data1<-cbind(id2, id.year2, id.committee2, id.ep2, data1)

colnames(data1)<-c("ID",
                   "Year",
                   "Com",
                   "EP",
                   "COD",
                   "NatPol",
                   "PNatPol",
                   "Loyalty",
                   "Inc",
                   "ComInc",
                   "Attend",
                   "INI.cum",
                   "INI",
                   "COD.lag",
                   "Chair")


#Make dummies for position on commitee
Substitute<-as.numeric(MEP$PositionCommittee=="Substitute")
Member<-as.numeric(MEP$PositionCommittee=="Member")
ViceChair<-as.numeric(MEP$PositionCommittee=="Vice-Chair")

#Multivariate normal prior for b-parameters.

K=11
mu.prior=rep(0,K)
Sigma.prior=diag(0.1,K)

K.att=3
mu.p.att=rep(0,K.att)
Sigma.p.att=diag(0.1,K.att)

#Parameters for informed priors (imputation)
m.natpol=mean(data1$NatPol, na.rm=T)
m.pnatpol=mean(data1$PNatPol, na.rm=T)

source("RtoBugs.txt")
writeDatafileR(list(data1,
                    Subst=Substitute,
                    Member=Member,
                    ViceC=ViceChair,
                    m.natpol=m.natpol,
                    m.pnpol=m.pnatpol,
                    N.year=length(unique(MEP$Year)),
                    N.com=length(unique(MEP$Committee)),
                    N.ep=length(unique(MEP$EP)),
                    N.id=length(unique(MEP$ID)),
                    N=length(MEP$ID), 
                    K=K,
                    mu.prior=mu.prior,
                    Si.prior=Sigma.prior,
                    K.att=K.att,
                    mu.p.att=mu.p.att,
                    Si.p.att=Sigma.p.att),
               towhere="model_alt/data_alt.txt")
